let map;
let directionsService;
let directionsRenderer;
let trafficLayer;
let autocompleteStart;
let autocompleteEnd;
let markers = [];
let busMarkers = [];
let geocoder;

// Weather API key (replace with your own OpenWeatherMap API key)
const WEATHER_API_KEY = 'YOUR_OPENWEATHERMAP_API_KEY';

function initMap() {
    map = new google.maps.Map(document.getElementById('map'), {
        center: { lat: 22.5744, lng: 88.3629 }, // Default center Kolkata
        zoom: 12,
        styles: [
            { elementType: 'geometry', stylers: [{ color: '#f5f5f5' }] },
            { elementType: 'labels.icon', stylers: [{ visibility: 'off' }] },
            { elementType: 'labels.text.fill', stylers: [{ color: '#616161' }] },
            { elementType: 'labels.text.stroke', stylers: [{ color: '#f5f5f5' }] },
            { featureType: 'administrative.land_parcel', elementType: 'labels.text.fill', stylers: [{ color: '#bdbdbd' }] },
            { featureType: 'poi', elementType: 'labels.text.fill', stylers: [{ color: '#757575' }] },
            { featureType: 'road', elementType: 'geometry', stylers: [{ color: '#ffffff' }] },
            { featureType: 'road.arterial', elementType: 'labels.text.fill', stylers: [{ color: '#9e9e9e' }] },
            { featureType: 'road.highway', elementType: 'geometry', stylers: [{ color: '#f8cdd6' }] },
            { featureType: 'road.highway', elementType: 'labels.text.fill', stylers: [{ color: '#616161' }] },
            { featureType: 'transit', elementType: 'labels.text.fill', stylers: [{ color: '#757575' }] },
            { featureType: 'water', elementType: 'geometry', stylers: [{ color: '#e3f2fd' }] }
        ]
    });

    directionsService = new google.maps.DirectionsService();
    directionsRenderer = new google.maps.DirectionsRenderer();
    directionsRenderer.setMap(map);

    trafficLayer = new google.maps.TrafficLayer();

    autocompleteStart = new google.maps.places.Autocomplete(document.getElementById('start'));
    autocompleteEnd = new google.maps.places.Autocomplete(document.getElementById('end'));

    geocoder = new google.maps.Geocoder();

    addBusMarkers(busMarkers);
}

function addBusMarkers(locations) {
    locations.forEach(location => {
        const marker = new google.maps.Marker({
            position: location,
            map: map,
            title: 'Bus Stop',
            icon: 'http://maps.google.com/mapfiles/ms/icons/bus.png' // Use a bus icon
        });
        busMarkers.push(marker);
    });
}

function calculateRoutes() {
    const start = document.getElementById('start').value;
    const end = document.getElementById('end').value;

    if (!start || !end) {
        alert('Please enter both start and end locations');
        return;
    }

    const request = {
        origin: start,
        destination: end,
        travelMode: google.maps.TravelMode.DRIVING,
        provideRouteAlternatives: true,
        drivingOptions: {
            departureTime: new Date(),  // Specifies the desired time of departure.
            trafficModel: 'bestguess'   // Other options: 'optimistic', 'pessimistic'
        }
    };

    directionsService.route(request, function(result, status) {
        if (status === google.maps.DirectionsStatus.OK) {
            displayRoutes(result);
        } else {
            alert('Failed to get routes: ' + status);
        }
    });
}

function displayRoutes(result) {
    const routes = result.routes;
    const routeList = document.getElementById('routeList');
    routeList.innerHTML = '';

    markers.forEach(marker => marker.setMap(null));
    markers = [];

    // Remove existing polylines if any
    if (window.routePolylines) {
        window.routePolylines.forEach(poly => poly.setMap(null));
    }
    window.routePolylines = [];

    const startLocation = result.routes[0].legs[0].start_location;
    const endLocation = result.routes[0].legs[0].end_location;

    markers.push(new google.maps.Marker({
        position: startLocation,
        map: map,
        title: 'Start',
        icon: 'http://maps.google.com/mapfiles/ms/icons/green-dot.png'
    }));

    markers.push(new google.maps.Marker({
        position: endLocation,
        map: map,
        title: 'End',
        icon: 'http://maps.google.com/mapfiles/ms/icons/red-dot.png'
    }));

    routes.sort((a, b) => {
        const distanceA = a.legs[0].distance.value;
        const distanceB = b.legs[0].distance.value;
        const trafficLevelA = getTrafficLevel(a);
        const trafficLevelB = getTrafficLevel(b);

        if (distanceA === distanceB) {
            return trafficLevelA - trafficLevelB;
        }
        return distanceA - distanceB;
    });

    let optimalRouteIndex = 0;
    const routeColors = ['#28a745', '#ffc107', '#dc3545', '#007bff', '#8e44ad']; // green, yellow, red, blue, purple

    routes.forEach((route, index) => {
        const routeInfo = document.createElement('div');
        const routeDistance = route.legs[0].distance.text;
        const routeDuration = route.legs[0].duration.text;
        const trafficCondition = getTrafficLevel(route);
        // Simulate road condition rating (1-5 stars) based on traffic and random factor
        const roadConditionRating = getRoadConditionRating(route);
        fetchPredictedDuration(route, index, routeInfo);
        routeInfo.className = 'route-info';
        const trafficSignalCount = estimateTrafficSignals(route);
        routeInfo.innerHTML = `
          <h3>Route ${index + 1} ${index === optimalRouteIndex ? '<span style="color: #28a745;">(Optimal)</span>' : ''}</h3>
          <p>Distance: ${routeDistance}</p>
          <p>Duration: ${routeDuration}</p>
          <p>Traffic Condition: ${trafficCondition}/10</p>
          <p>Road Condition: <span class="road-rating">${'★'.repeat(roadConditionRating)}${'☆'.repeat(5-roadConditionRating)}</span> (${roadConditionRating}/5)</p>
          <p>Predicted Duration: <span id="predictedDurationValue-${index}"></span></p>
          <p>Estimated Traffic Signals: <span style="font-weight:bold; color:#1976d2;">${trafficSignalCount}</span></p>
        `;
        routeInfo.addEventListener('click', () => {
            showRoute(index);
            document.querySelector('#routesContainer').appendChild(routeInfo);
        });
        routeList.appendChild(routeInfo);
        // Draw colored polyline for each route
        const polyline = new google.maps.Polyline({
            path: route.overview_path,
            strokeColor: routeColors[index % routeColors.length],
            strokeOpacity: 0.7,
            strokeWeight: 5
        });
        polyline.setMap(map);
        window.routePolylines.push(polyline);
    });

    const bounds = new google.maps.LatLngBounds();
    routes.forEach(route => {
        route.overview_path.forEach(point => {
            bounds.extend(point);
        });
    });
    map.fitBounds(bounds);

    // Store routes for showRoute
    window.lastDisplayedRoutes = result.routes;
}

function fetchPredictedDuration(route, index, routeInfo) {
    const currentTime = new Date();
    const hour = currentTime.getHours();
    const dayOfWeek = currentTime.getDay();

    fetch('/api/get_predicted_duration', {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            hour: hour,
            day_of_week: dayOfWeek,
            distance: route.legs[0].distance.value,
            duration_in_traffic: route.legs[0].duration_in_traffic ? route.legs[0].duration_in_traffic.value : route.legs[0].duration.value
        })
    })
    .then(response => {
        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }
        return response.json(); // Proceed to parse only if the response is OK
    })
    .then(data => {
        console.log(data); // Proceed with your logic here
    })
    .catch(error => {
        console.error('Error fetching predicted duration:', error);
    });
    
}

function formatDuration(durationInSeconds) {
    const hours = Math.floor(durationInSeconds / 3600);
    const minutes = Math.floor((durationInSeconds % 3600) / 60);
    const seconds = durationInSeconds % 60;
    return `${hours}h ${minutes}m ${seconds}s`;
}
function calculateRouteAndTrafficLevel(origin, destination, apiKey) {

    const directionsUrl = `https://maps.googleapis.com/maps/api/directions/json?origin=${origin}&destination=${destination}&departure_time=now&key=${apiKey}`;

    // Fetch the route data with traffic information
    fetch(directionsUrl)
        .then(response => response.json())
        .then(data => {
            const route = data.routes[0];  // Get the first route
            const trafficLevel = getTrafficLevel(route);
            console.log(`Traffic level: ${trafficLevel}/10`);
        })
        .catch(error => {
            console.error('Error fetching directions:', error);
        });
}


// function getTrafficLevel(route) {
//     const durationInTraffic = route.legs[0].duration_in_traffic ? route.legs[0].duration_in_traffic.value : route.legs[0].duration.value;
//     const regularDuration = route.legs[0].duration.value;

//     // Calculate traffic ratio
//     const trafficRatio = durationInTraffic / regularDuration;

//     // If there's no significant traffic, keep a lower bound on traffic level
//     let trafficLevel = Math.round((trafficRatio - 1) * 10);

//     // Ensure trafficLevel is between 1 and 10
//     trafficLevel = Math.min(Math.max(trafficLevel, 1), 10); 

//     return trafficLevel;
// }
function getTrafficLevel(route) {
    // Use duration_in_traffic if available, otherwise fall back to duration
    const durationInTraffic = route.legs[0].duration_in_traffic ? route.legs[0].duration_in_traffic.value : route.legs[0].duration.value;
    const regularDuration = route.legs[0].duration.value;

    // Calculation
    const trafficRatio = durationInTraffic / regularDuration;

    
    let trafficLevel;

    if (trafficRatio <= 1.1) {
        trafficLevel = 1; // Very light traffic
    } else if (trafficRatio <= 1.25) {
        trafficLevel = 3; // Light traffic
    } else if (trafficRatio <= 1.5) {
        trafficLevel = 5; // Moderate traffic
    } else if (trafficRatio <= 1.75) {
        trafficLevel = 7; // Heavy traffic
    } else {
        trafficLevel = 10; // Severe traffic
    }

    return trafficLevel;
}




function showRoute(routeIndex) {
    // Remove all existing route polylines
    if (window.routePolylines && window.routePolylines.length) {
        window.routePolylines.forEach(poly => poly.setMap(null));
    }
    window.routePolylines = [];
    // Get the routes from the last displayRoutes call
    const routes = window.lastDisplayedRoutes;
    if (!routes || !routes[routeIndex]) return;
    const route = routes[routeIndex];
    // Draw only the selected route in blue
    const polyline = new google.maps.Polyline({
        path: route.overview_path,
        strokeColor: '#1976d2',
        strokeOpacity: 1.0,
        strokeWeight: 6
    });
    polyline.setMap(map);
    window.routePolylines.push(polyline);
    // Zoom to fit the selected route
    const bounds = new google.maps.LatLngBounds();
    route.overview_path.forEach(point => bounds.extend(point));
    map.fitBounds(bounds);
}

function resetMap() {
    document.getElementById('start').value = '';
    document.getElementById('end').value = '';
    document.getElementById('routeList').innerHTML = '';
    markers.forEach(marker => marker.setMap(null));
    markers = [];
    polylines.forEach(polyline => polyline.setMap(null));
    polylines = [];
    busMarkers.forEach(marker => marker.setMap(null));
    busMarkers = [];
    map.setCenter({ lat: 22.5744, lng: 88.3629 });
    map.setZoom(12);

    addBusMarkers(busMarkersData);
}

function refreshStatus() {
    alert('Status refreshed');
}

function changeMapType() {
    const mapType = document.getElementById('mapType').value;
    map.setMapTypeId(mapType);
}

function toggleTrafficLayer() {
    if (trafficLayer.getMap()) {
        trafficLayer.setMap(null);
    } else {
        trafficLayer.setMap(map);
    }
}

function zoomIn() {
    map.setZoom(map.getZoom() + 1);
}

function zoomOut() {
    map.setZoom(map.getZoom() - 1);
}

function getRouteColor(index) {
    switch (index) {
        case 0: return '#28a745'; // Green for the optimal route
        case 1: return '#ffc107'; // Yellow for the medium traffic route
        case 2: return '#dc3545'; // Red for the high traffic route
        default: return '#007bff'; // Blue for any other routes
    }
}
////////
function calculateRoutes() {
    const start = document.getElementById('start').value;
    const end = document.getElementById('end').value;

    if (!start || !end) {
        alert('Please enter both start and end locations');
        return;
    }

    const request = {
        origin: start,
        destination: end,
        travelMode: google.maps.TravelMode.DRIVING,
        provideRouteAlternatives: true,
        drivingOptions: {
            departureTime: new Date(),
            trafficModel: 'bestguess'
        }
    };

    directionsService.route(request, function(result, status) {
        if (status === google.maps.DirectionsStatus.OK) {
            displayRoutes(result);
        } else {
            alert('Failed to get routes: ' + status);
        }
    });
}

function useCurrentLocation(target) {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(function(position) {
            const lat = position.coords.latitude;
            const lng = position.coords.longitude;
            const latlng = { lat: lat, lng: lng };
            geocoder.geocode({ location: latlng }, function(results, status) {
                if (status === 'OK' && results[0]) {
                    document.getElementById(target).value = results[0].formatted_address;
                    map.setCenter(latlng);
                    map.setZoom(15);
                } else {
                    alert('Could not determine address from your location.');
                }
            });
        }, function() {
            alert('Unable to retrieve your location.');
        });
    } else {
        alert('Geolocation is not supported by this browser.');
    }
}

// Add this helper function at the end of the file
function getRoadConditionRating(route) {
    // Example: Use traffic level and a random factor to simulate road condition
    const trafficLevel = getTrafficLevel(route);
    // Lower trafficLevel = better road, add some randomness
    let base = 5 - Math.floor(trafficLevel / 2);
    base = Math.max(1, Math.min(5, base + Math.floor(Math.random() * 2) - 1));
    return base;
}

// Fetch weather for a given lat/lng
function fetchWeather(lat, lng, callback) {
    const url = `https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lng}&appid=${WEATHER_API_KEY}&units=metric`;
    fetch(url)
        .then(response => response.json())
        .then(data => callback(data))
        .catch(() => callback(null));
}

// Add search box above the map
window.addEventListener('DOMContentLoaded', function() {
    const mapContainer = document.getElementById('map');
    if (mapContainer) {
        const searchBoxDiv = document.createElement('div');
        searchBoxDiv.style.textAlign = 'center';
        searchBoxDiv.style.marginBottom = '10px';
        searchBoxDiv.innerHTML = `
            <input id="search-location" type="text" placeholder="Search for a location..." style="width: 60%; padding: 6px; font-size: 16px;">
            <button id="search-location-btn" style="padding: 6px 12px; font-size: 16px;">Search</button>
        `;
        mapContainer.parentNode.insertBefore(searchBoxDiv, mapContainer);

        document.getElementById('search-location-btn').addEventListener('click', function() {
            const address = document.getElementById('search-location').value;
            if (!address) return;
            geocoder.geocode({ address: address }, function(results, status) {
                if (status === 'OK' && results[0]) {
                    map.setCenter(results[0].geometry.location);
                    map.setZoom(15);
                    // Optionally add a marker for the searched location
                    const marker = new google.maps.Marker({
                        map: map,
                        position: results[0].geometry.location,
                        title: address
                    });
                    markers.push(marker);
                } else {
                    alert('Location not found.');
                }
            });
        });
    }

    // Remove Street View button creation and insertion
    // const streetViewBtn = document.createElement('button');
    // streetViewBtn.textContent = 'Street View';
    // streetViewBtn.style = 'padding: 6px 12px; font-size: 16px; margin-left: 10px;';
    // streetViewBtn.onclick = function() { ... };
    // mapContainer.parentNode.insertBefore(streetViewBtn, mapContainer.nextSibling);

    // Add Street View Directions (step-by-step) button above the map
    const streetViewStepsBtn = document.createElement('button');
    streetViewStepsBtn.textContent = 'Street View Directions';
    streetViewStepsBtn.style = 'padding: 6px 12px; font-size: 16px; margin-left: 10px;';
    streetViewStepsBtn.onclick = function() {
        const start = document.getElementById('start').value;
        const end = document.getElementById('end').value;
        if (!start || !end) {
            alert('Please enter both start and end locations');
            return;
        }
        // Request directions for step-by-step navigation
        directionsService.route({
            origin: start,
            destination: end,
            travelMode: google.maps.TravelMode.DRIVING
        }, function(result, status) {
            if (status === 'OK' && result.routes.length > 0) {
                const steps = result.routes[0].legs[0].steps;
                showStreetViewStep(steps, 0);
            } else {
                alert('Could not get directions for Street View Directions.');
            }
        });
    };
    mapContainer.parentNode.insertBefore(streetViewStepsBtn, mapContainer.nextSibling);

    // Helper to show a step in Street View with instructions and navigation
    function showStreetViewStep(steps, stepIndex) {
        const step = steps[stepIndex];
        const panorama = new google.maps.StreetViewPanorama(
            document.getElementById('map'), {
                position: step.start_location,
                pov: { heading: step.heading || 0, pitch: 0 },
                zoom: 1
            }
        );
        map.setStreetView(panorama);
        // Remove any existing overlay
        let overlay = document.getElementById('streetview-step-overlay');
        if (overlay) overlay.remove();
        // Create overlay for instructions and navigation
        overlay = document.createElement('div');
        overlay.id = 'streetview-step-overlay';
        overlay.style.position = 'absolute';
        overlay.style.bottom = '30px';
        overlay.style.left = '50%';
        overlay.style.transform = 'translateX(-50%)';
        overlay.style.background = 'rgba(255,255,255,0.95)';
        overlay.style.padding = '16px 24px';
        overlay.style.borderRadius = '8px';
        overlay.style.boxShadow = '0 2px 8px rgba(0,0,0,0.2)';
        overlay.style.zIndex = '2000';
        overlay.style.minWidth = '320px';
        // Step instruction and distance
        overlay.innerHTML = `
            <div style="font-size:18px; font-weight:bold; margin-bottom:8px;">${step.instructions}</div>
            <div style="font-size:16px; color:#555; margin-bottom:12px;">Distance: ${step.distance.text}</div>
            <button id="prev-step-btn" style="margin-right:12px; padding:6px 16px;">Previous</button>
            <button id="next-step-btn" style="padding:6px 16px;">Next</button>
            <div style="margin-top:8px; font-size:14px; color:#888;">Step ${stepIndex+1} of ${steps.length}</div>
        `;
        mapContainer.style.position = 'relative';
        mapContainer.appendChild(overlay);
        // Navigation handlers
        document.getElementById('prev-step-btn').onclick = function() {
            if (stepIndex > 0) showStreetViewStep(steps, stepIndex - 1);
        };
        document.getElementById('next-step-btn').onclick = function() {
            if (stepIndex < steps.length - 1) showStreetViewStep(steps, stepIndex + 1);
        };
    }

    // Helper to add a CSS arrow overlay
    function addStreetViewArrow() {
        // Remove any existing arrow
        const existingArrow = document.getElementById('streetview-arrow-overlay');
        if (existingArrow) existingArrow.remove();
        // Create arrow
        const arrow = document.createElement('div');
        arrow.id = 'streetview-arrow-overlay';
        arrow.style.position = 'absolute';
        arrow.style.top = '50%';
        arrow.style.left = '50%';
        arrow.style.transform = 'translate(-50%, -50%)';
        arrow.style.width = '0';
        arrow.style.height = '0';
        arrow.style.borderLeft = '30px solid transparent';
        arrow.style.borderRight = '30px solid transparent';
        arrow.style.borderBottom = '60px solid #4285F4';
        arrow.style.opacity = '0.7';
        arrow.style.zIndex = '1000';
        arrow.title = 'Direction to destination';
        // Insert arrow into map container
        mapContainer.style.position = 'relative';
        mapContainer.appendChild(arrow);
    }
});

// Helper: Estimate number of traffic signals between source and destination
function estimateTrafficSignals(route) {
    // This is a simple estimation: count intersections (where maneuver is 'turn', 'left', 'right', etc.)
    // In real-world, you'd use a dataset of traffic signals or an API
    let count = 0;
    if (route && route.legs && route.legs[0] && route.legs[0].steps) {
        route.legs[0].steps.forEach(step => {
            if (step.maneuver && (
                step.maneuver.includes('turn') ||
                step.maneuver.includes('left') ||
                step.maneuver.includes('right') ||
                step.maneuver.includes('uturn')
            )) {
                count++;
            }
        });
    }
    // Add a minimum threshold for realism
    return Math.max(count, Math.floor(route.legs[0].distance.value / 2000)); // at least 1 per 2km
}