const busMarkersData=[
    { lat: 22.5151, lng: 88.3931 }, // Acropolis Mall
    { lat: 22.5142, lng: 88.3981 }, // GST Bhavan
    { lat: 22.5198, lng: 88.3821 }, // KASBA
    { lat: 22.5536, lng: 88.3492 }, // Park Street
    { lat: 22.4666, lng: 88.3604 }  // Garia
];